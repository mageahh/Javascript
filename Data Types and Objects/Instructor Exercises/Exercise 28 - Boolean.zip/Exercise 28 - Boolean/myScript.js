// JavaScript Boolean Type & Boolen Object

// create boolean using new keyword
var b = new Boolean(true);

document.write(b + "<br>");

document.write(b.valueOf() + "<br>");

// create boolean assigning true or false to a variable
var x = true;
var y = false;

var z = x.toString();

document.write(z + "<br>");

// conditional statement

if(true) {
    
    document.write("Condition with true state.<br>");
    
}

if(false) {
    
    document.write("Condition with false state.<br>");
    
}
if(1) {
    
    document.write("Condition with 1/true state.<br>");
    
}

if(0) {
    
    document.write("Condition with 0/false state.<br>");
    
}

if ( 2 <  3 ) {
    
    document.write("2 is less than 3");
    
}












