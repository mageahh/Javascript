// JavaScript null & undefined Data Type


// undefined
var x;
document.write(x + "<br>"); // display undefiend
document.write(typeof(x) + "<br>"); // display undefined

// null 
var y = null; 
document.write(y + "<br>"); // display null
document.write(typeof(y) + "<br>"); // display object

