// JavaScript Cookies

// create cookies
document.cookie = "userFirstName=Irfan;expires= Thu, 22 Jan 2017 12:00:00 UTC";

document.cookie = "userLastName=Dayan;expires= Thu, 22 Jan 2017 12:00:00 UTC";

// read cookies
//alert(document.cookie);

// delete cookies
document.cookie = "userFirstName=Irfan;expires= Thu, 22 Jan 2010 12:00:00 UTC";

alert(document.cookie);