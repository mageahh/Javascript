// JavaScript window history object

/*
	- window
		- screen
		- history	

*/



// length property returns the number of URLs in history listStyleType
document.write("<br>User history lenght: " + window.history.length + "<br>");


// load previous URL
//history.back();

// loads next URL
//history.forward();


// go forward one page.
//history.go(1);

// go back 2 page
//history.go(-2);
