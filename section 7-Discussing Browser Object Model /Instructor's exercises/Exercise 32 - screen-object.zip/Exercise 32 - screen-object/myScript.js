// JavaScript window screen object

/*
	- window
		- screen	

*/

// user's screen width
document.write(window.screen.width + "<br>");

// user's screen height
document.write(screen.height + "<br>");


// returns width & height minu interface like winows taskbar and etc.
document.write("Available width: " + screen.availWidth + "<br>");
document.write("Available height: " + screen.availHeight + "<br>");

// screen color & pixel depth
document.write("Color depth: " + screen.colorDepth + "<br>");
document.write("Pixel depth: " + screen.pixelDepth + "<br>");
